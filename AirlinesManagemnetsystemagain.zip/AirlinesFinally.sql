SELECT * FROM project.customer;
Select *FROM customer where Age<25;
 Select *FROM customer where Country="Lahore" AND Nationality="Male";
 SELECT * FROM customer
WHERE Age>30 AND Country= "Lahore";

